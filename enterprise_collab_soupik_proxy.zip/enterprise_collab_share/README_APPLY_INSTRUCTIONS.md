# Enterprise Collab + Proxy On/Off Changes

## What's Included
15 files changed across:
- `scenarios/MacOS/mac_enterprise_collab/` — proxy on/off code files, loop logging, fail logging, JSON scenario updates
- `scenarios/MacOS/_library/Teams/` — teams_join_meeting and teams_setup updates
- `scenarios/MacOS/_library/web/web_clear_cache/` — web_clear_cache.json tweaks
- `scenarios/app_scenario.py` — minor changes

## How to Apply

### Option 1: Git Patch (Recommended)
This preserves exact diffs and is cleanest. Your teammate should run from the **repo root**:

```bash
# Make sure they're on latest master first
git checkout master
git pull

# Apply the patch
git apply enterprise_collab_changes.patch

# If there are conflicts, use 3-way merge:
git apply --3way enterprise_collab_changes.patch
```

### Option 2: Zip File (Manual Copy)
Extract `enterprise_collab_files.zip` — the folder structure inside mirrors the repo layout.
Copy/overwrite the extracted `scenarios/` folder into the repo root:

```
# From where you extracted the zip:
xcopy /E /Y files\scenarios\ <repo-root>\scenarios\
```

Or just manually copy the folders into their matching locations in the repo.

## Notes
- These changes were diffed against commit `38dc72275d` on branch `user/soupik/mac_outlook_only` (based on `master` at `94703f7cc4`)
- The repo origin was ADO (`msftdevicespartners.visualstudio.com/Power/_git/hobl`), now on GitHub — the patch is repo-content-only (no remote info), so it works regardless of which remote your teammate uses
- New files (code_1ANJY4X.py, code_1ARKC3A.py, code_1KILLOF.py, code_1PROXON.py, code_FAILLOG.py, code_LOOPLOG.py, code_LOOPSUM.py) are included in both the patch and zip
